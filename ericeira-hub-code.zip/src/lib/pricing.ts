/** Fonte única de verdade para preços e regras financeiras (servidor). */
export const CREDIT_PACKS = {
  pack_12: { credits: 12, amountCents: 5900, name: "Pack Iniciante (12 Créditos)" },
  pack_35: { credits: 35, amountCents: 17500, name: "Ericeira Pass (35 Créditos)" },
  pack_70: { credits: 70, amountCents: 31500, name: "Pack Comunidade (70 Créditos)" },
} as const;

export type PackId = keyof typeof CREDIT_PACKS;

export function isPackId(value: unknown): value is PackId {
  return typeof value === "string" && Object.prototype.hasOwnProperty.call(CREDIT_PACKS, value);
}

/** Valor de referência de 1 crédito em euros (usado para sugerir custo em créditos). */
export const CREDIT_VALUE_EUR = 5;

/** Comissão da plataforma nas compras diretas (20%). */
export const PLATFORM_COMMISSION_RATE = 0.2;

/** Validade dos créditos após cada compra. */
export const CREDITS_VALIDITY_DAYS = 90;

export function suggestedCreditsForPrice(priceEur: number): number {
  return Math.max(1, Math.round(priceEur / CREDIT_VALUE_EUR));
}
